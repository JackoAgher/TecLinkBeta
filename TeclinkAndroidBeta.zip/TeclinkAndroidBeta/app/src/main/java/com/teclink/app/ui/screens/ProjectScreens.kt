package com.teclink.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teclink.app.data.Project
import com.teclink.app.ui.CompatibilityBar
import com.teclink.app.ui.OutlinePill
import com.teclink.app.ui.TagChip
import com.teclink.app.ui.TeclinkLogo
import com.teclink.app.ui.TopTitleBar
import com.teclink.app.ui.theme.TeclinkBackground
import com.teclink.app.ui.theme.TeclinkBlue
import com.teclink.app.ui.theme.TeclinkBlueSoft
import com.teclink.app.ui.theme.TeclinkBorder
import com.teclink.app.ui.theme.TeclinkGreen
import com.teclink.app.ui.theme.TeclinkGreenSoft
import com.teclink.app.ui.theme.TeclinkInk
import com.teclink.app.ui.theme.TeclinkMuted

@Composable
fun ProjectFeedScreen(
    projects: List<Project>,
    savedIds: List<String>,
    onOpenProject: (Project) -> Unit,
    onToggleSaved: (Project) -> Unit,
    onNotifications: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("Para ti") }
    val categories = listOf("Para ti", "Desarrollo", "Datos", "IoT")
    val visibleProjects = projects.filter { project ->
        val matchesQuery = query.isBlank() || project.title.contains(query, true) ||
            project.organization.contains(query, true) || project.skills.any { it.contains(query, true) }
        val matchesCategory = category == "Para ti" || project.category.equals(category, true)
        matchesQuery && matchesCategory
    }

    Column(modifier = Modifier.fillMaxSize().background(TeclinkBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TeclinkLogo(modifier = Modifier.weight(1f), iconSize = 34)
            IconButton(onClick = onNotifications, modifier = Modifier.size(39.dp)) {
                Icon(Icons.Filled.Notifications, contentDescription = "Notificaciones", tint = TeclinkInk, modifier = Modifier.size(21.dp))
            }
            Box(
                modifier = Modifier
                    .padding(start = 5.dp)
                    .size(31.dp)
                    .clip(CircleShape)
                    .background(TeclinkBlueSoft)
                    .clickable(onClick = onNotifications),
                contentAlignment = Alignment.Center
            ) {
                Text("AM", fontSize = 9.sp, color = TeclinkBlue, fontWeight = FontWeight.SemiBold)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 17.dp, end = 17.dp, top = 14.dp, bottom = 17.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("Hola, Ana 👋", fontSize = 21.sp, color = TeclinkInk, fontWeight = FontWeight.Bold)
                Text("Tu próximo reto empieza aquí.", fontSize = 11.sp, color = TeclinkMuted, modifier = Modifier.padding(top = 2.dp))
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.weight(1f).height(47.dp),
                        placeholder = { Text("Proyecto, habilidad o equipo", color = TeclinkMuted, fontSize = 10.sp, maxLines = 1) },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        singleLine = true,
                        shape = RoundedCornerShape(11.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TeclinkBlue,
                            unfocusedBorderColor = TeclinkBorder,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedLeadingIconColor = TeclinkBlue,
                            unfocusedLeadingIconColor = TeclinkMuted,
                            cursorColor = TeclinkBlue
                        )
                    )
                    Surface(
                        modifier = Modifier.size(45.dp).clip(RoundedCornerShape(11.dp)).clickable {
                            category = if (category == "Para ti") "Desarrollo" else "Para ti"
                        },
                        color = TeclinkBlue,
                        shape = RoundedCornerShape(11.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Tune, contentDescription = "Cambiar filtro", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEach { option ->
                        TagChip(label = option, selected = category == option) { category = option }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Proyectos recomendados", color = TeclinkInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("Mejor match ↓", color = TeclinkBlue, fontSize = 9.sp, fontWeight = FontWeight.Medium)
                }
            }
            if (visibleProjects.isEmpty()) {
                item { EmptyState(title = "No encontramos proyectos", subtitle = "Prueba otra búsqueda o categoría.") }
            } else {
                items(visibleProjects, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        isSaved = project.id in savedIds,
                        onOpen = { onOpenProject(project) },
                        onToggleSaved = { onToggleSaved(project) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProjectCard(
    project: Project,
    isSaved: Boolean,
    onOpen: () -> Unit,
    onToggleSaved: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, TeclinkBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(TeclinkBlueSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Computer, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(18.dp))
                }
                Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(project.title, color = TeclinkInk, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(project.organization, color = TeclinkMuted, fontSize = 9.sp, maxLines = 1)
                }
                IconButton(onClick = onToggleSaved, modifier = Modifier.size(31.dp)) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = if (isSaved) "Quitar de guardados" else "Guardar proyecto",
                        tint = if (isSaved) TeclinkBlue else TeclinkMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${project.mode} · ${project.duration} · ${project.openings} plazas", color = TeclinkMuted, fontSize = 9.sp)
                Spacer(Modifier.weight(1f))
                Text(project.posted, color = TeclinkMuted, fontSize = 8.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                project.skills.take(3).forEach { TagChip(it) }
            }
            CompatibilityBar(match = project.match)
        }
    }
}

@Composable
fun ProjectDetailScreen(
    project: Project,
    isSaved: Boolean,
    hasApplied: Boolean,
    onBack: () -> Unit,
    onToggleSaved: () -> Unit,
    onApply: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        TopTitleBar(title = "Detalle del proyecto", onBack = onBack) {
            IconButton(onClick = onToggleSaved, modifier = Modifier.size(40.dp)) {
                Icon(
                    if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = if (isSaved) "Quitar guardado" else "Guardar proyecto",
                    tint = if (isSaved) TeclinkBlue else TeclinkInk,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 19.dp, vertical = 13.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(35.dp).clip(RoundedCornerShape(10.dp)).background(TeclinkBlueSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.BusinessCenter, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(18.dp))
                }
                Text(project.category.uppercase(), modifier = Modifier.padding(start = 8.dp), color = TeclinkBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(project.posted, color = TeclinkMuted, fontSize = 8.sp)
            }

            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(project.title, color = TeclinkInk, fontSize = 22.sp, lineHeight = 27.sp, fontWeight = FontWeight.Bold)
                Text(project.organization, color = TeclinkMuted, fontSize = 10.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinePill(project.mode, Icons.Filled.Computer)
                OutlinePill(project.duration, Icons.Filled.Schedule)
                OutlinePill("${project.openings} plazas", Icons.Filled.Groups)
            }

            CompatibilityBar(match = project.match, modifier = Modifier.fillMaxWidth())

            Text("Sobre el proyecto", color = TeclinkInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                text = project.description,
                color = TeclinkMuted,
                fontSize = 11.sp,
                lineHeight = 18.sp
            )

            Text("Herramientas requeridas", color = TeclinkInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                project.skills.forEach { TagChip(it) }
                if (project.id == "mobility-campus") TagChip("Git")
            }

            Text("Tu contribución", color = TeclinkInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            project.contributions.forEach { contribution ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                    Text(contribution, color = TeclinkMuted, fontSize = 10.sp, lineHeight = 16.sp)
                }
            }

            Surface(color = Color(0xFFF4F6FC), shape = RoundedCornerShape(13.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(34.dp).clip(CircleShape).background(TeclinkBlueSoft), contentAlignment = Alignment.Center) {
                        Text(project.leaderName.split(' ').take(2).mapNotNull { it.firstOrNull() }.joinToString(""), color = TeclinkBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(modifier = Modifier.weight(1f).padding(start = 9.dp)) {
                        Text(project.leaderName, color = TeclinkInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        Text(project.leaderRole, color = TeclinkMuted, fontSize = 8.sp, maxLines = 1)
                    }
                    Icon(Icons.Filled.CheckCircle, contentDescription = "Líder verificado", tint = TeclinkBlue, modifier = Modifier.size(17.dp))
                }
            }
        }

        Column(modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 18.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(
                onClick = onApply,
                modifier = Modifier.fillMaxWidth().height(43.dp),
                shape = RoundedCornerShape(9.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (hasApplied) TeclinkGreen else TeclinkBlue)
            ) {
                Icon(if (hasApplied) Icons.Filled.Check else Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Text(if (hasApplied) "Postulación enviada" else "Postularse", modifier = Modifier.padding(start = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            Text("Convocatoria abierta hasta el 20 de octubre", modifier = Modifier.fillMaxWidth(), color = TeclinkMuted, fontSize = 8.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
fun SavedProjectsScreen(
    projects: List<Project>,
    onOpenProject: (Project) -> Unit,
    onToggleSaved: (Project) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(TeclinkBackground)) {
        Text(
            "Proyectos guardados",
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 19.dp, vertical = 18.dp),
            color = TeclinkInk,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold
        )
        if (projects.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                EmptyState(title = "Aún no guardas proyectos", subtitle = "Toca el marcador en una tarjeta para volver a ella después.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(projects, key = { it.id }) { project ->
                    ProjectCard(project, isSaved = true, onOpen = { onOpenProject(project) }, onToggleSaved = { onToggleSaved(project) })
                }
            }
        }
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(TeclinkBlueSoft), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(23.dp))
        }
        Text(title, color = TeclinkInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = TeclinkMuted, fontSize = 10.sp)
    }
}
