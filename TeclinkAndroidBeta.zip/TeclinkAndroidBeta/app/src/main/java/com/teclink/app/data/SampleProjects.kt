package com.teclink.app.data

object SampleProjects {
    val all = listOf(
        Project(
            id = "mobility-campus",
            title = "Movilidad Campus",
            organization = "Laboratorio de Innovación · Tec de Monterrey",
            mode = "Remoto",
            duration = "8 semanas",
            openings = 2,
            match = 95,
            skills = listOf("Kotlin", "MVVM", "MySQL"),
            category = "Desarrollo",
            posted = "Hace 2 h",
            description = "Creamos una app Android para consultar rutas, horarios y disponibilidad del transporte universitario en tiempo real. Queremos que llegar al campus sea más fácil y sostenible.\n\nBuscamos estudiantes para desarrollar el MVP junto a un equipo de diseño y backend. Tendrás mentoría semanal, experiencia para tu portafolio y constancia de participación.",
            contributions = listOf(
                "Construir pantallas y consumir la API de rutas.",
                "Aplicar MVVM y colaborar con Git: 10 h/semana."
            ),
            leaderName = "Diego Ramírez",
            leaderRole = "Líder de Proyecto · Ing. de Software"
        ),
        Project(
            id = "energia-iot",
            title = "Panel de energía IoT",
            organization = "EcoTech Universitario",
            mode = "Híbrido",
            duration = "12 semanas",
            openings = 3,
            match = 88,
            skills = listOf("Python", "MQTT", "MySQL"),
            category = "IoT",
            posted = "Hace 5 h",
            description = "Visualiza el consumo energético de edificios universitarios y ayuda a detectar oportunidades de ahorro con sensores conectados.",
            contributions = listOf(
                "Integrar lecturas de sensores vía MQTT.",
                "Crear paneles de consumo y reportes semanales."
            ),
            leaderName = "Sofía Castillo",
            leaderRole = "Coordinadora · EcoTech"
        ),
        Project(
            id = "tutorias",
            title = "Tutorías entre estudiantes",
            organization = "Comunidad Aprende+",
            mode = "Remoto",
            duration = "6 semanas",
            openings = 2,
            match = 76,
            skills = listOf("React", "Node.js", "Git"),
            category = "Desarrollo",
            posted = "Hace 1 d",
            description = "Conecta a estudiantes que quieren compartir conocimientos y crea una comunidad de aprendizaje entre pares.",
            contributions = listOf(
                "Diseñar el flujo para agendar una tutoría.",
                "Implementar componentes accesibles y documentados."
            ),
            leaderName = "Luis Herrera",
            leaderRole = "Fundador · Comunidad Aprende+"
        ),
        Project(
            id = "datos-abiertos",
            title = "Datos abiertos para tu ciudad",
            organization = "CivicLab Monterrey",
            mode = "Remoto",
            duration = "10 semanas",
            openings = 4,
            match = 72,
            skills = listOf("Python", "SQL", "Figma"),
            category = "Datos",
            posted = "Hace 2 d",
            description = "Convierte datos públicos en herramientas sencillas para entender mejor los servicios de la ciudad.",
            contributions = listOf(
                "Limpiar y documentar datasets municipales.",
                "Prototipar visualizaciones con el equipo de UX."
            ),
            leaderName = "Valeria Soto",
            leaderRole = "Product Lead · CivicLab"
        )
    )
}
