package com.teclink.app.data

data class Project(
    val id: String,
    val title: String,
    val organization: String,
    val mode: String,
    val duration: String,
    val openings: Int,
    val match: Int,
    val skills: List<String>,
    val category: String,
    val posted: String,
    val description: String,
    val contributions: List<String>,
    val leaderName: String,
    val leaderRole: String,
    val iconLabel: String = "</>"
)
