package com.teclink.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.teclink.app.data.Project
import com.teclink.app.data.SampleProjects
import com.teclink.app.ui.screens.AuthScreen
import com.teclink.app.ui.screens.ConversationScreen
import com.teclink.app.ui.screens.NotificationsScreen
import com.teclink.app.ui.screens.ProfileScreen
import com.teclink.app.ui.screens.ProjectDetailScreen
import com.teclink.app.ui.screens.ProjectFeedScreen
import com.teclink.app.ui.screens.SavedProjectsScreen
import com.teclink.app.ui.screens.MessagesScreen
import com.teclink.app.ui.theme.TeclinkBackground
import kotlinx.coroutines.launch

enum class MainTab {
    PROJECTS, SAVED, MESSAGES, PROFILE
}

@Composable
fun TeclinkApp() {
    var signedIn by rememberSaveable { mutableStateOf(false) }
    var selectedTab by rememberSaveable { mutableStateOf(MainTab.PROJECTS) }
    var selectedProjectId by rememberSaveable { mutableStateOf(SampleProjects.all.first().id) }
    var returnTab by rememberSaveable { mutableStateOf(MainTab.PROJECTS) }
    var showDetail by rememberSaveable { mutableStateOf(false) }
    var showNotifications by rememberSaveable { mutableStateOf(false) }
    var openConversation by rememberSaveable { mutableStateOf(false) }
    val savedIds = remember { mutableStateListOf<String>() }
    val appliedIds = remember { mutableStateListOf<String>() }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val selectedProject = SampleProjects.all.firstOrNull { it.id == selectedProjectId }
        ?: SampleProjects.all.first()

    fun toggleSaved(project: Project) {
        if (project.id in savedIds) savedIds.remove(project.id) else savedIds.add(project.id)
    }

    fun openProject(project: Project, from: MainTab = selectedTab) {
        selectedProjectId = project.id
        returnTab = from
        showDetail = true
    }

    Scaffold(
        containerColor = TeclinkBackground,
        bottomBar = {
            if (signedIn && !showNotifications && !openConversation) {
                TeclinkBottomBar(
                    selectedTab = selectedTab,
                    onSelect = {
                        selectedTab = it
                        showDetail = false
                    }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { contentPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
        ) {
            when {
                !signedIn -> AuthScreen(
                    onAuthenticated = { signedIn = true },
                    onMessage = { message -> scope.launch { snackbarHostState.showSnackbar(message) } }
                )

                showNotifications -> NotificationsScreen(
                    onBack = { showNotifications = false }
                )

                openConversation -> ConversationScreen(
                    onBack = { openConversation = false }
                )

                showDetail -> ProjectDetailScreen(
                    project = selectedProject,
                    isSaved = selectedProject.id in savedIds,
                    hasApplied = selectedProject.id in appliedIds,
                    onBack = {
                        showDetail = false
                        selectedTab = returnTab
                    },
                    onToggleSaved = { toggleSaved(selectedProject) },
                    onApply = {
                        if (selectedProject.id !in appliedIds) appliedIds.add(selectedProject.id)
                        scope.launch { snackbarHostState.showSnackbar("¡Listo! Tu postulación quedó registrada en esta beta.") }
                    }
                )

                else -> when (selectedTab) {
                    MainTab.PROJECTS -> ProjectFeedScreen(
                        projects = SampleProjects.all,
                        savedIds = savedIds,
                        onOpenProject = { openProject(it, MainTab.PROJECTS) },
                        onToggleSaved = ::toggleSaved,
                        onNotifications = { showNotifications = true }
                    )

                    MainTab.SAVED -> SavedProjectsScreen(
                        projects = SampleProjects.all.filter { it.id in savedIds },
                        onOpenProject = { openProject(it, MainTab.SAVED) },
                        onToggleSaved = ::toggleSaved
                    )

                    MainTab.MESSAGES -> MessagesScreen(
                        onOpenConversation = { openConversation = true }
                    )

                    MainTab.PROFILE -> ProfileScreen(
                        appliedCount = appliedIds.size,
                        onMessage = { message -> scope.launch { snackbarHostState.showSnackbar(message) } }
                    )
                }
            }
        }
    }
}
