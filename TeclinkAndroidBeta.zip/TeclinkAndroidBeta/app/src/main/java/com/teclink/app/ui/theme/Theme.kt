package com.teclink.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val TeclinkBlue = Color(0xFF1E5BEA)
val TeclinkInk = Color(0xFF172644)
val TeclinkMuted = Color(0xFF71809B)
val TeclinkBackground = Color(0xFFF4F6FB)
val TeclinkBorder = Color(0xFFE3E9F3)
val TeclinkBlueSoft = Color(0xFFEAF0FF)
val TeclinkGreen = Color(0xFF11834D)
val TeclinkGreenSoft = Color(0xFFE8F6EE)

private val TeclinkColors = lightColorScheme(
    primary = TeclinkBlue,
    onPrimary = Color.White,
    secondary = TeclinkGreen,
    onSecondary = Color.White,
    background = TeclinkBackground,
    onBackground = TeclinkInk,
    surface = Color.White,
    onSurface = TeclinkInk,
    outline = TeclinkBorder
)

@Composable
fun TeclinkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TeclinkColors,
        content = content
    )
}
