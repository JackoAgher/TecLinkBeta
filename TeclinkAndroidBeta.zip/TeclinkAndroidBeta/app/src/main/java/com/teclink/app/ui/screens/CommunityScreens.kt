package com.teclink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teclink.app.ui.TopTitleBar
import com.teclink.app.ui.theme.TeclinkBackground
import com.teclink.app.ui.theme.TeclinkBlue
import com.teclink.app.ui.theme.TeclinkBlueSoft
import com.teclink.app.ui.theme.TeclinkBorder
import com.teclink.app.ui.theme.TeclinkInk
import com.teclink.app.ui.theme.TeclinkMuted

private data class DemoMessage(val text: String, val isMine: Boolean)

@Composable
fun MessagesScreen(onOpenConversation: () -> Unit) {
    val conversations = listOf(
        MessagePreview("Diego Ramírez", "¿Te interesa conocer más del proyecto?", "10:42", "DR", true),
        MessagePreview("Sofía Castillo", "Gracias por tu interés en EcoTech", "Ayer", "SC", false),
        MessagePreview("Equipo Aprende+", "Te damos la bienvenida al equipo", "Lun", "A+", false)
    )

    Column(modifier = Modifier.fillMaxSize().background(TeclinkBackground)) {
        Text(
            "Mensajes",
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 19.dp, vertical = 17.dp),
            color = TeclinkInk,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(13.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(conversations, key = { it.name }) { conversation ->
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenConversation),
                    color = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TeclinkBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(43.dp).clip(CircleShape).background(TeclinkBlueSoft), contentAlignment = Alignment.Center) {
                            Text(conversation.initials, color = TeclinkBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(modifier = Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(conversation.name, color = TeclinkInk, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text(conversation.lastMessage, color = TeclinkMuted, fontSize = 9.sp, maxLines = 1)
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(conversation.time, color = TeclinkMuted, fontSize = 8.sp)
                            if (conversation.unread) Box(Modifier.size(7.dp).clip(CircleShape).background(TeclinkBlue))
                        }
                    }
                }
            }
        }
    }
}

private data class MessagePreview(
    val name: String,
    val lastMessage: String,
    val time: String,
    val initials: String,
    val unread: Boolean
)

@Composable
fun ConversationScreen(onBack: () -> Unit) {
    val messages = androidx.compose.runtime.remember {
        mutableStateListOf(
            DemoMessage("Hola, Ana. Vi tu perfil y creo que encaja muy bien con Movilidad Campus.", false),
            DemoMessage("¡Hola, Diego! Me interesa mucho el proyecto. ¿Qué sigue?", true),
            DemoMessage("¿Te parece si coordinamos una llamada esta semana?", false)
        )
    }
    var draft by rememberSaveable { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(TeclinkBackground)) {
        TopTitleBar(title = "Diego Ramírez", onBack = onBack)
        Surface(color = Color(0xFFEAF0FF), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 7.dp)) {
            Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Chat, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(15.dp))
                Text("Movilidad Campus", modifier = Modifier.padding(start = 7.dp), color = TeclinkBlue, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            items(messages) { message ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = if (message.isMine) Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (message.isMine) TeclinkBlue else Color.White,
                        shape = RoundedCornerShape(14.dp),
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth(.82f)
                    ) {
                        Text(
                            text = message.text,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            color = if (message.isMine) Color.White else TeclinkInk,
                            fontSize = 10.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe un mensaje…", fontSize = 10.sp, color = TeclinkMuted) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                shape = RoundedCornerShape(22.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TeclinkBlue,
                    unfocusedBorderColor = TeclinkBorder,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    cursorColor = TeclinkBlue
                )
            )
            IconButton(
                onClick = {
                    if (draft.isNotBlank()) {
                        messages.add(DemoMessage(draft.trim(), true))
                        draft = ""
                    }
                },
                modifier = Modifier.size(42.dp).clip(CircleShape).background(TeclinkBlue)
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Enviar", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun NotificationsScreen(onBack: () -> Unit) {
    val notices = listOf(
        Notice("Tu perfil hizo match con Movilidad Campus", "95% de compatibilidad · hace 2 h", "MC"),
        Notice("Diego Ramírez te envió un mensaje", "Movilidad Campus · hace 3 h", "DR"),
        Notice("Se acerca el cierre de una convocatoria", "Panel de energía IoT · hace 1 d", "IoT")
    )
    Column(modifier = Modifier.fillMaxSize().background(TeclinkBackground)) {
        TopTitleBar(title = "Notificaciones", onBack = onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(13.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(notices) { notice ->
                Surface(color = Color.White, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, TeclinkBorder)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(39.dp).clip(CircleShape).background(TeclinkBlueSoft), contentAlignment = Alignment.Center) {
                            Text(notice.badge, color = TeclinkBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(modifier = Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(notice.title, color = TeclinkInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Text(notice.subtitle, color = TeclinkMuted, fontSize = 8.sp)
                        }
                        Icon(Icons.Filled.Notifications, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

private data class Notice(val title: String, val subtitle: String, val badge: String)
