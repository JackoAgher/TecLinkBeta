package com.teclink.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teclink.app.ui.theme.TeclinkBlue
import com.teclink.app.ui.theme.TeclinkBlueSoft
import com.teclink.app.ui.theme.TeclinkBorder
import com.teclink.app.ui.theme.TeclinkInk

@Composable
fun TeclinkLogo(
    modifier: Modifier = Modifier,
    inverted: Boolean = false,
    iconSize: Int = 38
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(
            modifier = Modifier
                .size(iconSize.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(if (inverted) Color.White else TeclinkBlue),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.AccountTree,
                contentDescription = null,
                tint = if (inverted) TeclinkBlue else Color.White,
                modifier = Modifier.size((iconSize * .58f).dp)
            )
        }
        Text(
            text = "TecLink",
            fontWeight = FontWeight.Bold,
            fontSize = 19.sp,
            color = if (inverted) Color.White else TeclinkInk
        )
    }
}

@Composable
fun TagChip(
    label: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val chipModifier = modifier
        .clip(CircleShape)
        .background(if (selected) TeclinkBlue else TeclinkBlueSoft)
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
        .padding(horizontal = 11.dp, vertical = 6.dp)

    Text(
        text = label,
        modifier = chipModifier,
        color = if (selected) Color.White else TeclinkBlue,
        fontSize = 11.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
        maxLines = 1
    )
}

@Composable
fun CompatibilityBar(match: Int, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(11.dp))
            .background(com.teclink.app.ui.theme.TeclinkGreenSoft)
            .padding(horizontal = 11.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Porcentaje de Compatibilidad", color = TeclinkGreenText, fontSize = 10.sp)
            Spacer(Modifier.weight(1f))
            Text("$match% Match", color = TeclinkGreenText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(CircleShape)
                .background(Color(0xFFC5E9D2))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(match / 100f)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(com.teclink.app.ui.theme.TeclinkGreen)
            )
        }
    }
}

private val TeclinkGreenText = Color(0xFF087443)

@Composable
fun TeclinkBottomBar(selectedTab: MainTab, onSelect: (MainTab) -> Unit) {
    Surface(
        color = Color.White,
        shadowElevation = 8.dp,
        border = BorderStroke(.5.dp, TeclinkBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(top = 7.dp, bottom = 5.dp, start = 6.dp, end = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(MainTab.PROJECTS, selectedTab, "Proyectos", Icons.Filled.Work, onSelect)
            NavItem(MainTab.SAVED, selectedTab, "Guardados", Icons.Filled.Bookmark, onSelect)
            NavItem(MainTab.MESSAGES, selectedTab, "Mensajes", Icons.Filled.Chat, onSelect)
            NavItem(MainTab.PROFILE, selectedTab, "Perfil", Icons.Filled.Person, onSelect)
        }
    }
}

@Composable
private fun NavItem(
    tab: MainTab,
    selectedTab: MainTab,
    label: String,
    icon: ImageVector,
    onSelect: (MainTab) -> Unit
) {
    val selected = selectedTab == tab
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(15.dp))
            .clickable { onSelect(tab) }
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) TeclinkBlue else Color(0xFF7888A2),
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = label,
            color = if (selected) TeclinkBlue else Color(0xFF7888A2),
            fontSize = 9.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
fun TopTitleBar(
    title: String,
    onBack: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 15.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.material3.IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Volver",
                tint = TeclinkInk
            )
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f).padding(start = 8.dp),
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = TeclinkInk
        )
        if (trailing != null) trailing()
    }
}

@Composable
fun OutlinePill(text: String, icon: ImageVector) {
    Surface(
        shape = RoundedCornerShape(11.dp),
        color = Color(0xFFF4F6FB),
        border = BorderStroke(1.dp, Color.Transparent)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF52627F), modifier = Modifier.size(15.dp))
            Text(text, modifier = Modifier.padding(start = 5.dp), color = TeclinkInk, fontSize = 10.sp)
        }
    }
}
