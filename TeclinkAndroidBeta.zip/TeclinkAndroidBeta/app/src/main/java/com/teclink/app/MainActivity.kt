package com.teclink.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.teclink.app.ui.TeclinkApp
import com.teclink.app.ui.theme.TeclinkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TeclinkTheme {
                TeclinkApp()
            }
        }
    }
}
