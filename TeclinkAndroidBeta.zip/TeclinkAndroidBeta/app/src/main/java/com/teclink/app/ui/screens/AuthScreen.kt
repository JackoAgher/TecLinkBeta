package com.teclink.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teclink.app.ui.TeclinkLogo
import com.teclink.app.ui.theme.TeclinkBlue
import com.teclink.app.ui.theme.TeclinkBorder
import com.teclink.app.ui.theme.TeclinkInk
import com.teclink.app.ui.theme.TeclinkMuted

@Composable
fun AuthScreen(
    onAuthenticated: () -> Unit,
    onMessage: (String) -> Unit
) {
    var isRegistering by rememberSaveable { mutableStateOf(false) }
    var isCandidate by rememberSaveable { mutableStateOf(true) }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TeclinkBlue)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(.38f)
                .padding(horizontal = 22.dp, vertical = 14.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                TeclinkLogo(inverted = true)
                Spacer(Modifier.weight(1f))
                Text(
                    text = "Tu talento.\nEl siguiente\ngran proyecto.",
                    modifier = Modifier.fillMaxWidth(.78f),
                    color = Color.White,
                    fontSize = 25.sp,
                    lineHeight = 27.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Conecta con líderes y construye tu futuro en ingeniería.",
                    modifier = Modifier.fillMaxWidth(.83f).padding(top = 8.dp, bottom = 10.dp),
                    color = Color.White.copy(alpha = .88f),
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
            TechOrbit(
                modifier = Modifier
                    .size(150.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 35.dp, y = 17.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(.69f)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color.White)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 21.dp, vertical = 17.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                AuthTab("Iniciar sesión", selected = !isRegistering, modifier = Modifier.weight(1f)) {
                    isRegistering = false
                }
                AuthTab("Registrarme", selected = isRegistering, modifier = Modifier.weight(1f)) {
                    isRegistering = true
                }
            }

            Text(
                text = if (isRegistering) "Crea tu cuenta para empezar" else "¿Cómo quieres conectar?",
                color = TeclinkInk,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 1.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RoleChoice(
                    title = "Soy Candidato",
                    icon = Icons.Filled.School,
                    selected = isCandidate,
                    modifier = Modifier.weight(1f)
                ) { isCandidate = true }
                RoleChoice(
                    title = "Soy Líder de Proyecto",
                    icon = Icons.Filled.BusinessCenter,
                    selected = !isCandidate,
                    modifier = Modifier.weight(1f)
                ) { isCandidate = false }
            }

            Text("Correo universitario", color = TeclinkInk, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("nombre@universidad.edu", fontSize = 12.sp, color = TeclinkMuted) },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(17.dp)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                shape = RoundedCornerShape(11.dp),
                colors = authFieldColors()
            )

            Text("Contraseña", color = TeclinkInk, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Mínimo 8 caracteres", fontSize = 12.sp, color = TeclinkMuted) },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(17.dp)) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (passwordVisible) "Ocultar contraseña" else "Mostrar contraseña",
                            modifier = Modifier.size(17.dp),
                            tint = TeclinkMuted
                        )
                    }
                },
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                shape = RoundedCornerShape(11.dp),
                colors = authFieldColors()
            )

            if (!isRegistering) {
                Text(
                    text = "¿Olvidaste tu contraseña?",
                    modifier = Modifier.fillMaxWidth().clickable { onMessage("La recuperación de contraseña estará disponible en la siguiente etapa.") },
                    textAlign = TextAlign.End,
                    color = TeclinkBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Button(
                onClick = onAuthenticated,
                modifier = Modifier.fillMaxWidth().height(46.dp).padding(top = 2.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TeclinkBlue)
            ) {
                Icon(Icons.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                Text(
                    text = if (isRegistering) "Crear cuenta" else "Iniciar sesión",
                    modifier = Modifier.padding(start = 8.dp),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(Modifier.weight(1f).height(1.dp).background(TeclinkBorder))
                Text("  o continúa con  ", color = TeclinkMuted, fontSize = 9.sp)
                Box(Modifier.weight(1f).height(1.dp).background(TeclinkBorder))
            }

            androidx.compose.material3.OutlinedButton(
                onClick = onAuthenticated,
                modifier = Modifier.fillMaxWidth().height(42.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TeclinkBorder)
            ) {
                Icon(Icons.Filled.School, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(16.dp))
                Text("Cuenta universitaria", modifier = Modifier.padding(start = 8.dp), color = TeclinkInk, fontSize = 11.sp)
            }
            Text(
                text = "Al continuar, aceptas nuestros Términos de uso\ny la Política de privacidad.",
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 4.dp),
                textAlign = TextAlign.Center,
                color = TeclinkMuted,
                fontSize = 8.sp,
                lineHeight = 12.sp
            )
        }
    }
}

@Composable
private fun AuthTab(title: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            title,
            color = if (selected) TeclinkBlue else TeclinkMuted,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(.78f)
                .height(2.dp)
                .clip(CircleShape)
                .background(if (selected) TeclinkBlue else Color.Transparent)
        )
    }
}

@Composable
private fun RoleChoice(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .height(58.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(if (selected) Color(0xFFEAF0FF) else Color.White)
            .border(1.dp, if (selected) TeclinkBlue else TeclinkBorder, RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) TeclinkBlue else TeclinkMuted, modifier = Modifier.size(16.dp))
        Text(title, color = if (selected) TeclinkBlue else TeclinkInk, fontSize = 8.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun TechOrbit(modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width * .6f, size.height * .48f)
            val radius = size.minDimension * .43f
            drawCircle(Color.White.copy(alpha = .16f), radius, center, style = Stroke(width = 1.dp.toPx()))
            drawCircle(Color.White.copy(alpha = .16f), radius * .7f, center, style = Stroke(width = 1.dp.toPx()))
            drawLine(Color.White.copy(alpha = .23f), Offset(center.x - radius, center.y + radius * .45f), Offset(center.x + radius, center.y - radius * .45f), strokeWidth = 1.dp.toPx())
            drawCircle(Color(0xFFB9CFFF), 5.dp.toPx(), Offset(center.x - radius * .8f, center.y - radius * .6f))
        }
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(start = 28.dp, top = 10.dp)
                .size(44.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Text("</>", color = TeclinkBlue, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 36.dp, bottom = 12.dp)
                .size(22.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFE5F6EC)),
            contentAlignment = Alignment.Center
        ) {
            Text("✓", color = Color(0xFF16965A), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun authFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = TeclinkBlue,
    unfocusedBorderColor = TeclinkBorder,
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color(0xFFF6F8FC),
    focusedLeadingIconColor = TeclinkBlue,
    unfocusedLeadingIconColor = TeclinkMuted,
    cursorColor = TeclinkBlue
)
