package com.teclink.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.teclink.app.ui.TagChip
import com.teclink.app.ui.theme.TeclinkBackground
import com.teclink.app.ui.theme.TeclinkBlue
import com.teclink.app.ui.theme.TeclinkBlueSoft
import com.teclink.app.ui.theme.TeclinkBorder
import com.teclink.app.ui.theme.TeclinkInk
import com.teclink.app.ui.theme.TeclinkMuted

@Composable
fun ProfileScreen(
    appliedCount: Int,
    onMessage: (String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf("Ana Martínez") }
    var about by rememberSaveable { mutableStateOf("Me apasiona crear aplicaciones que resuelvan problemas reales. Busco colaborar en proyectos Android y aprender junto a equipos multidisciplinarios.") }
    var editName by rememberSaveable { mutableStateOf(name) }
    var editAbout by rememberSaveable { mutableStateOf(about) }
    var showEditDialog by rememberSaveable { mutableStateOf(false) }
    val skills = remember { mutableStateListOf("Kotlin", "MVVM", "MySQL", "Git", "Android Studio", "Python", "REST API", "Figma") }

    Column(modifier = Modifier.fillMaxSize().background(TeclinkBackground)) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 19.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Mi perfil", modifier = Modifier.weight(1f), color = TeclinkInk, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = { onMessage("La configuración de cuenta estará disponible próximamente.") }, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Filled.Settings, contentDescription = "Configuración", tint = TeclinkInk, modifier = Modifier.size(19.dp))
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(17.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TeclinkBorder)
                ) {
                    Column {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(49.dp).background(TeclinkBlue),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text("PERFIL CANDIDATO", modifier = Modifier.padding(start = 13.dp).clip(CircleShape).background(Color.White.copy(alpha = .17f)).padding(horizontal = 9.dp, vertical = 5.dp), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFDCE7FF)), contentAlignment = Alignment.Center) {
                                    Text("AM", color = TeclinkBlue, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.weight(1f))
                                Text("• Disponible para proyectos", modifier = Modifier.clip(CircleShape).background(TeclinkBlueSoft).padding(horizontal = 9.dp, vertical = 6.dp), color = TeclinkBlue, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Text(name, color = TeclinkInk, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("Ingeniería en Sistemas Computacionales", color = TeclinkInk, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                            Text("Tecnológico de Monterrey · 6.º semestre", color = TeclinkMuted, fontSize = 9.sp)
                            androidx.compose.material3.OutlinedButton(
                                onClick = {
                                    editName = name
                                    editAbout = about
                                    showEditDialog = true
                                },
                                modifier = Modifier.fillMaxWidth().height(38.dp).padding(top = 2.dp),
                                shape = RoundedCornerShape(9.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, TeclinkBorder)
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(15.dp))
                                Text("Editar perfil", modifier = Modifier.padding(start = 7.dp), color = TeclinkInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProfileStat((4 + appliedCount).toString().padStart(2, '0'), "Postulaciones", Modifier.weight(1f))
                    ProfileStat("02", "Proyectos", Modifier.weight(1f))
                    ProfileStat(skills.size.toString().padStart(2, '0'), "Habilidades", Modifier.weight(1f))
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Sobre mí", color = TeclinkInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(about, color = TeclinkMuted, fontSize = 10.sp, lineHeight = 16.sp)
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Habilidades técnicas", color = TeclinkInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Row(
                            modifier = Modifier.clip(CircleShape).clickable {
                                if ("Compose" !in skills) skills.add("Compose")
                                else onMessage("Ya agregaste la habilidad de Compose.")
                            }.padding(horizontal = 4.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Añadir", color = TeclinkBlue, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                            Icon(Icons.Filled.Add, contentDescription = "Añadir habilidad", tint = TeclinkBlue, modifier = Modifier.size(14.dp))
                        }
                    }
                    skills.chunked(5).forEach { rowSkills ->
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            rowSkills.forEach { TagChip(it) }
                        }
                    }
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Proyecto destacado", color = TeclinkInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("Ver todo", color = TeclinkBlue, fontSize = 9.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clickable { onMessage("Tus proyectos aparecen en esta sección del perfil.") })
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onMessage("Finanzas para estudiantes · App Android · Kotlin · MVVM") },
                    shape = RoundedCornerShape(15.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TeclinkBorder)
                ) {
                    Row(modifier = Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(37.dp).clip(RoundedCornerShape(10.dp)).background(TeclinkBlueSoft), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Work, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(18.dp))
                        }
                        Column(modifier = Modifier.weight(1f).padding(start = 9.dp)) {
                            Text("Finanzas para estudiantes", color = TeclinkInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            Text("App Android · Kotlin · MVVM", color = TeclinkMuted, fontSize = 8.sp)
                        }
                        Icon(Icons.Filled.OpenInNew, contentDescription = "Ver proyecto", tint = TeclinkBlue, modifier = Modifier.size(17.dp))
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onMessage("Perfil de GitHub de Ana Martínez") }.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Code, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(16.dp))
                    Text("github.com/ana-martinez", modifier = Modifier.padding(start = 6.dp).weight(1f), color = TeclinkBlue, fontSize = 9.sp)
                    Icon(Icons.Filled.OpenInNew, contentDescription = null, tint = TeclinkBlue, modifier = Modifier.size(13.dp))
                }
            }
        }
    }

    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Editar perfil", color = TeclinkInk, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Nombre") },
                        singleLine = true,
                        colors = profileFieldColors()
                    )
                    OutlinedTextField(
                        value = editAbout,
                        onValueChange = { editAbout = it },
                        label = { Text("Sobre mí") },
                        minLines = 3,
                        colors = profileFieldColors()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    name = editName.ifBlank { name }
                    about = editAbout.ifBlank { about }
                    showEditDialog = false
                    onMessage("Perfil actualizado en este dispositivo.")
                }) { Text("Guardar", color = TeclinkBlue, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = { TextButton(onClick = { showEditDialog = false }) { Text("Cancelar", color = TeclinkMuted) } },
            containerColor = Color.White
        )
    }
}

@Composable
private fun ProfileStat(number: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, TeclinkBorder, RoundedCornerShape(12.dp))
            .padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(number, color = TeclinkBlue, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(label, color = TeclinkMuted, fontSize = 8.sp)
    }
}

@Composable
private fun profileFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = TeclinkBlue,
    unfocusedBorderColor = TeclinkBorder,
    focusedLabelColor = TeclinkBlue,
    cursorColor = TeclinkBlue
)
