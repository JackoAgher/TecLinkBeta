# Teclink Android Beta

Beta nativa para Android basada en los modelos de pantalla compartidos. Está hecha con Kotlin y Jetpack Compose y usa contenido de muestra.

## Abrir en Android Studio

1. Abre Android Studio y elige **Open**.
2. Selecciona la carpeta `TeclinkAndroidBeta`.
3. En **File > Settings > Build, Execution, Deployment > Build Tools > Gradle**, selecciona **Gradle JDK 21**. En esta laptop está instalado en `C:\Users\agher\.jdks\jbr-21.0.11`.
4. Acepta la sincronización de Gradle y descarga Android SDK Platform 36 si Android Studio lo solicita.
5. Ejecuta la configuración `app` en un emulador o dispositivo Android 8.0 o posterior.

El proyecto requiere Android SDK Platform 36. El Gradle Wrapper está incluido. Para generar un APK, usa **Build > Build Bundle(s) / APK(s) > Build APK(s)** o ejecuta `gradlew.bat :app:assembleDebug` desde la terminal integrada.

## Recorrido incluido

- Acceso y registro con selección entre candidato y líder de proyecto.
- Lista de proyectos con búsqueda, filtros por área y porcentaje de compatibilidad.
- Detalle de proyecto, marcador de guardado y estado de postulación.
- Proyectos guardados y barra inferior para proyectos, guardados, mensajes y perfil.
- Perfil editable, alta de una habilidad de muestra, conversaciones, envío local de mensajes y notificaciones.

## Alcance de esta beta

La autenticación y la cuenta universitaria llevan al recorrido de muestra; no hay cuentas reales ni backend. Los proyectos, mensajes, postulaciones y cambios de perfil se mantienen solo en memoria mientras la app está abierta. Los datos del perfil y algunas etiquetas se dejaron como contenido de demostración.

El entorno de creación no tenía Android SDK ni Gradle/JDK 17 instalados, así que el proyecto está preparado para sincronizarse en Android Studio, pero no se generó un APK ni se pudo compilar aquí.
